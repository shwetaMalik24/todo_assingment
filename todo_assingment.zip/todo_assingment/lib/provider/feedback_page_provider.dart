import 'package:flutter/cupertino.dart';
import 'package:todo_assingment/apis/api_response.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';
import 'package:todo_assingment/models/feedback_post_model.dart';
import 'package:todo_assingment/repository/feedback_page_repository.dart';
import 'package:todo_assingment/utils/preferences_utils.dart';

class FeedBackPageProvider extends ChangeNotifier {
  FeedBackRepository _feedBackRepository;
  ApiResponse<FeedbackPageModel> feedBackList;

  ApiResponse<FeedbackPageModel> get album => feedBackList;

  FeedBackPageProvider() {
    feedBackList = ApiResponse<FeedbackPageModel>();
    _feedBackRepository = FeedBackRepository();
    fetchFeedbackUIDetails();
  }

  fetchFeedbackUIDetails() async {
    feedBackList = ApiResponse.loading('Fetching Data');
    notifyListeners();
    try {
      FeedbackPageModel model = await _feedBackRepository.get();
      feedBackList = ApiResponse.completed(model);
      PreferencesUtils.setFormDetails(feedBackList.data);
      notifyListeners();
    } catch (e) {
      feedBackList = ApiResponse.error(e.toString());
      notifyListeners();
    }
  }
  postFeedBack(FeedBackPostModel list) async {
    feedBackList = ApiResponse.loading('Fetching Data');
    notifyListeners();
    try {
      FeedbackPageModel model = await _feedBackRepository.feedBackPost(list);
      feedBackList = ApiResponse.completed(model);
      PreferencesUtils.setFormDetails(feedBackList.data);
      notifyListeners();
    } catch (e) {
      feedBackList = ApiResponse.error(e.toString());
      notifyListeners();
    }
  }
}
