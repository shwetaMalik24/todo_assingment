import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:todo_assingment/apis/api_response.dart';
import 'package:todo_assingment/base_class.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';
import 'package:todo_assingment/models/feedback_post_model.dart';
import 'package:todo_assingment/provider/feedback_page_provider.dart';
import 'package:todo_assingment/utils/constants.dart';
import 'package:todo_assingment/utils/theme.dart';
import 'package:todo_assingment/widgets/button_widget.dart';
import 'package:todo_assingment/widgets/date_widget.dart';
import 'package:todo_assingment/widgets/drop_down_widget.dart';
import 'package:todo_assingment/widgets/text_field_widget.dart';

class FeedBackPage extends StatefulWidget {
  @override
  _FeedBackPageState createState() => _FeedBackPageState();
}

class _FeedBackPageState extends State<FeedBackPage> with BaseClass {
  DateTime currentDate = DateTime.now();
  var controllersList = <TextEditingController>[];
  List<Fields> fields;
  List<FeedBackPostModel> postData;
  String dropDownErr = "";
  String dateErr = "";
  Color borderDropDownColor;
  Color borderDateColor;

  @override
  void initState() {
    fields = <Fields>[];
    postData = <FeedBackPostModel>[];
    setState(() {
      borderDateColor = Colors.grey;
      borderDropDownColor = Colors.grey;
    });
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text(
          Constants.SURVEY,
          style: TextStyle(color: Colors.black),
          textAlign: TextAlign.left,
        ),
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
      ),
      body: GestureDetector(
        onTap: () {
          // FocusScopeNode currentFocus = FocusScope.of(context);
          // currentFocus.unfocus();
        },
        child: Consumer<FeedBackPageProvider>(
          builder: (context, myModel, child) {
            if (myModel.feedBackList.status == Status.COMPLETED) {
              if (myModel.feedBackList.data.fields != null) {
                for (int i = 0;
                    i < myModel.feedBackList.data.fields.length;
                    i++) {
                  if (myModel.feedBackList.data.fields[i].type ==
                          Constants.SHORT_TEXT ||
                      myModel.feedBackList.data.fields[i].type ==
                          Constants.EMAIL ||
                      myModel.feedBackList.data.fields[i].type ==
                          Constants.PHONE_NUMBER ||
                      myModel.feedBackList.data.fields[i].type ==
                          Constants.NUMBER) {
                    if (myModel.feedBackList.data.fields[i].controllerList ==
                        null) {
                      TextEditingController controller =
                          new TextEditingController();
                      myModel.feedBackList.data.fields[i].controllerList =
                          controller;
                    }
                  }
                }
              } else {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  Navigator.pushNamed(context, Constants.THANK_YOU_PAGE);
                });
              }
              if (myModel.feedBackList.data.fields != null) {
                fields = myModel.feedBackList.data.fields;
                return _buildFeedBackForm(myModel.feedBackList.data);
              }
              return Container(
                height: 0,
                width: 0,
              );
            } else if (myModel.feedBackList.status == Status.ERROR) {
              return Center(child: Text(myModel.feedBackList.message));
            } else {
              return Center(
                  child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(ThemeColor.textColor),
              ));
            }
          },
        ),
      ),
    );
  }

  _buildFeedBackForm(FeedbackPageModel _feedbackPageModel) {
    return SingleChildScrollView(
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                for (var field in _feedbackPageModel.fields)
                  if (field.id != null) ...[
                    if (field.type == Constants.SHORT_TEXT)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFieldForm(
                          key: UniqueKey(),
                          hintText: field.title,
                          controller: field.controllerList,
                          errorText: field.errorText,
                          keyboard: TextInputType.text,
                        ),
                      ),
                    if (field.type == Constants.DROP_DOWN)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            DropDownWidget(
                              choices: field.properties.choices,
                              title: field.title,
                              borderColor: borderDropDownColor,
                              onPressed: (value) {
                                setState(
                                  () {
                                    for (var item in fields) {
                                      if (item.id == field.id) {
                                        item.dropDownItem = value;
                                      }
                                    }
                                    field.dropDownItem = value;
                                    field.title = value;
                                  },
                                );
                              },
                            ),
                            if (dropDownErr != "")
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 14.0, top: 8.0),
                                child: Text(
                                  dropDownErr,
                                  style: TextStyle(
                                      color: ThemeColor.errorColor,
                                      fontSize: 12),
                                ),
                              )
                          ],
                        ),
                      ),
                    if (field.type == Constants.EMAIL)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFieldForm(
                          key: UniqueKey(),
                          hintText: field.title,
                          controller: field.controllerList,
                          keyboard: TextInputType.text,
                          errorText: field.errorText,
                        ),
                      ),
                    if (field.type == Constants.DATE)
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            DateWidget(
                              title: field.title,
                              borderColor: borderDateColor,
                              onPressed: () {
                                _selectDate(context, field).then(
                                  (value) {
                                    for (var item in fields) {
                                      if (item.id == field.id) {
                                        item.date = value;
                                      }
                                    }
                                    field.date = value;
                                  },
                                );
                              },
                            ),
                            if (dateErr != "")
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 14.0, top: 8.0),
                                child: Text(
                                  dateErr,
                                  style: TextStyle(
                                      color: ThemeColor.errorColor,
                                      fontSize: 12),
                                ),
                              )
                          ],
                        ),
                      ),
                    if (field.type == Constants.PHONE_NUMBER)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFieldForm(
                          key: UniqueKey(),
                          hintText: field.title,
                          controller: field.controllerList,
                          keyboard: TextInputType.number,
                          errorText: field.errorText,
                        ),
                      ),
                    if (field.type == Constants.NUMBER)
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                        child: TextFieldForm(
                          key: UniqueKey(),
                          hintText: field.title,
                          controller: field.controllerList,
                          keyboard: TextInputType.number,
                          errorText: field.errorText,
                        ),
                      ),
                  ],
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 10.0, top: 30),
                    child: Button(
                      title: Constants.SUBMIT,
                      onPressed: () {
                        _submitClicked(fields, context);
                      },
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  _submitClicked(List<Fields> fields, BuildContext context) {
    if (!validations(fields, context)) {
      FeedBackPostModel _feedbackPostModel = new FeedBackPostModel();
      for (var item in fields) {
        if (item.controllerList != null)
          _feedbackPostModel.fieldData = item.controllerList.text;
        _feedbackPostModel.fieldId = item.id;
        postData.add(_feedbackPostModel);
      }
      Provider.of<FeedBackPageProvider>(context, listen: false)
          .postFeedBack(_feedbackPostModel);
    }
  }

  bool validations(List<Fields> fields, BuildContext context) {
    bool isValidated = false;
    for (var item in fields) {
      if (item.type == Constants.PHONE_NUMBER) {
        validatePhoneNumber(item);
      }
      if (item.type == Constants.NUMBER) {
        validateAge(item);
      }
      if (item.validations.required) {
        if (item.dropDownItem != null && item.type == Constants.DROP_DOWN) {
          if (item.dropDownItem == "") {
            setState(() {
              borderDropDownColor = ThemeColor.errorColor;
              dropDownErr = Constants.SELECT_GENDER;
            });
            isValidated = true;
          } else {
            setState(() {
              borderDropDownColor = Colors.grey;
              dropDownErr = "";
            });
          }
        } else if (item.date != null && item.type == Constants.DATE) {
          if (item.date == "") {
            setState(() {
              borderDateColor = ThemeColor.errorColor;
              dateErr = Constants.ENTER_DATE;
            });
            isValidated = true;
          } else {
            setState(() {
              borderDateColor = Colors.grey;
              dateErr = "";
            });
          }
        } else if (item.controllerList != null) {
          if (item.controllerList.text == "") {
            isValidated = true;
            if (item.type == Constants.SHORT_TEXT) {
              setState(() {
                item.errorText = Constants.ENTER_NAME;
              });
            } else if (item.type == Constants.NUMBER) {
              setState(() {
                item.errorText = Constants.ENTER_AGE;
              });
            } else if (item.type == Constants.EMAIL) {
              setState(() {
                item.errorText = Constants.ENTER_EMAIL;
              });
            } else if (item.type == Constants.PHONE_NUMBER) {
              setState(() {
                item.errorText = Constants.ENTER_PHONE_NUMBER;
              });
            } //
          } else {
            if (item.type == Constants.SHORT_TEXT) {
              setState(() {
                item.errorText = null;
              });
            } else if (item.type == Constants.NUMBER) {
              setState(() {
                item.errorText = null;
              });
            } else if (item.type == Constants.EMAIL) {
              if (!validateEmail(item.controllerList.text)) {
                setState(() {
                  item.errorText = Constants.VALID_EMAIL_ERR;
                });
              } else {
                setState(() {
                  item.errorText = null;
                });
              }
            } else if (item.type == Constants.PHONE_NUMBER) {
              if (item.controllerList.text.length == 10) {
                setState(() {
                  item.errorText = null;
                });
              } else {
                setState(() {
                  item.errorText = Constants.VALID_MOBILE_ERR;
                });
              }
            } //
          }
        } // break;
      }
    }
    return isValidated;
  }

  validatePhoneNumber(Fields field) {
    if (field.type == Constants.PHONE_NUMBER) {
      print(field.controllerList.text.length);
      if (field.controllerList.text.length == 10) {
        setState(() {
          field.errorText = null;
        });
      } else {
        setState(() {
          field.errorText = Constants.VALID_MOBILE_ERR;
        });
      }
    }
  }

  validateAge(Fields field) {
    if (field.type == Constants.NUMBER) {
      print(field.controllerList.text.length);
      if (field.controllerList.text.length == 2) {
        setState(() {
          field.errorText = null;
        });
      } else {
        setState(() {
          field.errorText = Constants.VALID_AGE_ERR;
        });
      }
    }
  }

  Future<String> _selectDate(BuildContext context, Fields list) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        for (var item in fields) {
          if (item.id == list.id) {
            item.date = DateFormat(Constants.DATE_KEY).format(pickedDate);
          }
        }
        list.date = DateFormat(Constants.DATE_KEY).format(pickedDate);
        list.title = DateFormat(Constants.DATE_KEY).format(pickedDate);
        currentDate = pickedDate;
      });
    return DateFormat(Constants.DATE_KEY).format(pickedDate);
  }
}
