import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_assingment/apis/api_response.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';
import 'package:todo_assingment/provider/feedback_page_provider.dart';
import 'package:todo_assingment/utils/constants.dart';
import 'package:todo_assingment/utils/theme.dart';
import 'package:todo_assingment/widgets/button_widget.dart';

import '../base_class.dart';

class WelcomePage extends StatefulWidget {
  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> with BaseClass {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Consumer<FeedBackPageProvider>(
        builder: (context, myModel, child) {
          if (myModel.feedBackList.status == Status.COMPLETED) {
            return _buildUI(myModel.feedBackList.data);
          } else if (myModel.feedBackList.status == Status.ERROR) {
            return Center(child: Text(myModel.feedBackList.message));
          } else {
            return Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(ThemeColor.textColor),
            ));
          }
        },
      ),
    );
  }

  _buildUI(FeedbackPageModel _feedbackPageModel) {
    return Stack(
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.only(
                  top: MediaQuery.of(context).size.height * 0.2,
                  left: 24.0,
                  right: 24.0),
              child: Center(

                  child: Text(
                    _feedbackPageModel.welcomeScreen!=null?_feedbackPageModel.welcomeScreen.title : "",
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                textAlign: TextAlign.center,
              )),
            ),
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Center(
                child: Text(_feedbackPageModel.welcomeScreen!=null?_feedbackPageModel.welcomeScreen.description : "",
                    style: TextStyle(fontWeight: FontWeight.w600),
                    textAlign: TextAlign.center),
              ),
            ),
          ],
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.2),
            child: Button(
              title: Constants.START,
              onPressed: () {
                Navigator.pushNamed(context, Constants.FEEDBACK_PAGE);
              },
            ),
          ),
        )
      ],
    );
  }
}
