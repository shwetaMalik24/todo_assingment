import 'package:todo_assingment/utils/string_ext.dart';

class AppException implements Exception {
  final String _message;
  final String _prefix;

  AppException([this._message, this._prefix]);

  String toString() {
    if (_message.isNullEmptyOrWhitespace) {
      return "$_prefix";
    }
    return "$_prefix$_message";
  }
}

class FetchDataException extends AppException {
  FetchDataException([String message]) : super(message, "");
}

class BadRequestException extends AppException {
  BadRequestException([message]) : super(message, "Invalid Request");
}

class UnauthorisedException extends AppException {
  UnauthorisedException([message]) : super(message, "Unauthorised");
}

class InvalidInputException extends AppException {
  InvalidInputException([String message]) : super(message, "Invalid Input");
}
