import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:todo_assingment/apis/app_exception.dart';
import 'package:todo_assingment/apis/repository.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';
import 'package:todo_assingment/models/feedback_post_model.dart';
import 'package:todo_assingment/utils/constants.dart';

class FeedBackRepository extends Repository {
  Future<FeedbackPageModel> get() async {
    var responseJson;
    try {
      final url = Uri.parse(Constants.GET_URL);
      final response = await http.get(url);
      responseJson = getResponse(response);
      FeedbackPageModel.fromJson(responseJson);
      return FeedbackPageModel.fromJson(responseJson);
    } on SocketException {
      throw FetchDataException(Constants.NO_INTERNET_CONNECTION);
    } on TimeoutException {
      throw FetchDataException(Constants.NO_INTERNET_CONNECTION);
    } catch (e) {
      throw FetchDataException(Constants.ERROR_PLEASE_TRY_AGAIN_LATER);
    }
  }
  // ignore: missing_return
  Future<FeedbackPageModel> feedBackPost(FeedBackPostModel list) async {
    print(list);
    try {
      final url = Uri.parse(Constants.POST_URL);
      final http.Response response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{"field_id": list.fieldId,"field_data": list.fieldData}),
      );
      var responseJson = getResponse(response);
      var postFeedBackResponse = FeedbackPageModel.fromJson(responseJson);
      if (postFeedBackResponse != null) {
        return FeedbackPageModel.fromJson(responseJson);
      }
    } on SocketException {
      throw FetchDataException(Constants.NO_INTERNET_CONNECTION);
    } on TimeoutException {
      throw FetchDataException(Constants.NO_INTERNET_CONNECTION);
    } catch (e) {
      throw FetchDataException(Constants.ERROR_PLEASE_TRY_AGAIN_LATER);
    }
  }
}
