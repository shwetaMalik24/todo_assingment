import 'package:flutter/material.dart';
import 'package:todo_assingment/pages/feedback_page.dart';
import 'package:todo_assingment/pages/thankyou_page.dart';
import 'package:todo_assingment/pages/welcome_page.dart';

import 'constants.dart';

class RouteGenerator {
  // ignore: missing_return
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case Constants.INITIAL_ROUTE:
        return MaterialPageRoute(
          builder: (_) => WelcomePage(),
        );
        break;
      case Constants.FEEDBACK_PAGE:
        return MaterialPageRoute(
          builder: (_) => FeedBackPage(),
        );
        break;
      case Constants.THANK_YOU_PAGE:
        return MaterialPageRoute(
          builder: (_) => ThankYouPage(),
        );
        break;
    }
  }
}
