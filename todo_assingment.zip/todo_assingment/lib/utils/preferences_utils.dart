import 'dart:async' show Future;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';
import 'package:todo_assingment/utils/constants.dart';

class PreferencesUtils {
  static SharedPreferences _prefs;

  static Future<SharedPreferences> init() async {
    _prefs = await SharedPreferences.getInstance();
    return _prefs;
  }

  static Future<bool> setFormDetails(FeedbackPageModel _feedBackModel) async =>
      _prefs.setString(Constants.FEED_BACK_MODEL_KEY, json.encode(_feedBackModel));

  static String getFormDetails() =>
      _prefs.getString(Constants.FEED_BACK_MODEL_KEY);
}
