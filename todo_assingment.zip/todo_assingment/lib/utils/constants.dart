class Constants{

  ///api
  static const GET_URL="https://getx-todo-server.herokuapp.com";
  static const POST_URL="https://getx-todo-server.herokuapp.com";

  ///Strings
  static const NO_INTERNET_CONNECTION="No internet connection.";
  static const ERROR_PLEASE_TRY_AGAIN_LATER = "Error, Please try again later";
  static const OK="Ok";
  static const ALERT="Alert";
  static const ALERT_MSG="Fileds cannot be empty.";
  static const SURVEY="Survey";
  static const SUBMIT="SUBMIT";
  static const START="START";
  static const DATE="date";
  static const EMAIL="email";
  static const DROP_DOWN="dropdown";
  static const SHORT_TEXT="short_text";
  static const PHONE_NUMBER="phone_number";
  static const NUMBER="number";
  static const VALID_AGE_ERR="Enter valid age";
  static const VALID_MOBILE_ERR="Enter valid mobile number";
  static const VALID_EMAIL_ERR="Enter valid email";
  static const ENTER_PHONE_NUMBER= "Enter Phone Number";
  static const ENTER_EMAIL="Enter Email";
  static const ENTER_AGE="Enter Age";
  static const ENTER_NAME= "Enter Name";
  static const ENTER_DATE="Select Date";
  static const SELECT_GENDER="Select Gender";
  ///Routes
  static const INITIAL_ROUTE = '/';
  static const FEEDBACK_PAGE = 'FEEDBACK_PAGE';
  static const THANK_YOU_PAGE = 'THANK_YOU_PAGE';
  static const AGAIN = 'AGAIN';
  ///shared preference key
  static const FEED_BACK_MODEL_KEY = 'FEED_BACK_MODEL_KEY';

  ///Date Strings
  static const DATE_KEY = "EEE d MMM";
}