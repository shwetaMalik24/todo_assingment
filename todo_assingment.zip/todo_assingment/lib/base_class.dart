import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:todo_assingment/utils/constants.dart';

mixin BaseClass {
  Future<bool> isConnected() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      return true;
    } else {
      return false;
    }
  }

  showDialogue(BuildContext context, String title, String content) {
    print(context);
    Widget okButton = TextButton(
      child: Text(Constants.OK),
      onPressed: () {
        Navigator.of(context, rootNavigator: true).pop();
        //Navigator.of(context).pop();
      },
    );
    AlertDialog alert = AlertDialog(
      title: Text(title),
      content: Text(content),
      actions: [
        okButton,
      ],
    );
    showDialog(
      context: context,
      builder: (dialogueContext) {
        return alert;
      },
    );
  }

  bool validateEmail(String email) {
    return RegExp(
        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(email);
  }
}
