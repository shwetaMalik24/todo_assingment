import 'package:flutter/material.dart';
import 'package:todo_assingment/utils/theme.dart';

class DateWidget extends StatelessWidget{
  final title;
  final Function() onPressed;
  final Color borderColor;
  DateWidget({
    Key key,
    @required this.title,
    this.onPressed,
    this.borderColor
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        height: 55,
        padding: EdgeInsets.only(left: 12,right: 8),
        decoration: BoxDecoration(
          border: Border.all(color: borderColor),
          borderRadius: BorderRadius.all(
              Radius.circular(5.0) //                 <--- border radius here
          ),
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,style: Theme.of(context)
                    .textTheme
                    .subtitle1
                    .copyWith(color: ThemeColor.placeHolderColor, fontSize: 16),),
                Icon(
                  Icons.calendar_today,
                  color: ThemeColor.textColor,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

}