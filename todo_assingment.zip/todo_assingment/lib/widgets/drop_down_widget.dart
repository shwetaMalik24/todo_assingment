import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_assingment/models/feedback_page_model.dart';

class DropDownWidget extends StatelessWidget {
  final List<Choices> choices;
  final title;
  final Function(String value) onPressed;
  final String selectedItem;
  final Color borderColor;
  DropDownWidget({Key key, this.choices, this.title, this.onPressed,this.selectedItem,this.borderColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 55,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.0),
          color: Colors.white,
          border: Border.all(color: borderColor)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton(
          hint: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(title),
          ),
          value: selectedItem,
          items: choices
              .map<DropdownMenuItem<String>>(
                  (value) => new DropdownMenuItem<String>(
                        value: value.label,
                        child: new Text(value.label),
                      ))
              .toList(),
          onChanged: onPressed,
        ),
      ),
    );
  }
}
