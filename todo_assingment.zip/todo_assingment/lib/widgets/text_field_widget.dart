import 'package:flutter/material.dart';
import 'package:todo_assingment/utils/theme.dart';

class TextFieldForm extends StatelessWidget {
  final String hintText;
  final TextEditingController controller;
  final String labeltext;
  final String errorText;
  final TextInputType keyboard;
  TextFieldForm({Key key, this.hintText, this.controller, this.labeltext,this.keyboard,this.errorText})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: TextField(
        controller: controller,
        keyboardType:keyboard,
        decoration: InputDecoration(
          labelText: labeltext,
          errorText: errorText,
          counterText: "",
          //errorBorder: InputBorder.none,
          border: OutlineInputBorder(),
          hintText: hintText,
          hintStyle: TextStyle(color: ThemeColor.placeHolderColor),
        ),
      ),
    );
  }
}
