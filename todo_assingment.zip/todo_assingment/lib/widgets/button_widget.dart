import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:todo_assingment/utils/theme.dart';

class Button extends StatelessWidget {
  final title;
  final Function() onPressed;

  Button({
    Key key,
    @required this.title,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
            primary:ThemeColor.textColor, elevation: 4.0),
        onPressed: onPressed,
           child: Text(
              title,
              style: Theme.of(context)
                  .textTheme
                  .subtitle1
                  .copyWith(color: Colors.white, fontSize: 20),
            ),
      ),
    );
  }
}
