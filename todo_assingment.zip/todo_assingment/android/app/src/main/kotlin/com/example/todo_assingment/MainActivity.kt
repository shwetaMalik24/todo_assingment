package com.example.todo_assingment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
